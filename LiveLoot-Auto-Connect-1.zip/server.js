import express from "express";
import http from "node:http";
import { WebSocketServer, WebSocket } from "ws";
import { TikTokLiveConnection, WebcastEvent } from "tiktok-live-connector";

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: "/ws" });
app.use(express.static("public"));
app.get("/health", (_req,res) => res.json({ ok:true, service:"LiveLoot" }));

let liveConnection = null;
let activeUsername = null;
const clients = new Set();

function sendAll(payload) {
  const message = JSON.stringify(payload);
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN) client.send(message);
  }
}
function cleanUser(user) {
  return {
    username: user?.uniqueId || user?.nickname || "viewer",
    nickname: user?.nickname || user?.uniqueId || "צופה",
    avatar: user?.avatarThumb?.urlList?.[0] || user?.profilePicture?.url || ""
  };
}
async function stopLive() {
  if (liveConnection) {
    try { await liveConnection.disconnect(); } catch {}
  }
  liveConnection = null;
  activeUsername = null;
}
async function startLive(rawUsername) {
  const username = String(rawUsername || "").trim().replace(/^@/,"").replace(/\/.*$/,"");
  if (!/^[A-Za-z0-9._]{2,30}$/.test(username)) {
    throw new Error("שם המשתמש לא תקין. כתוב רק את שם המשתמש, בלי קישור.");
  }
  await stopLive();
  activeUsername = username;
  const conn = new TikTokLiveConnection(username, {
    processInitialData: false,
    fetchRoomInfoOnConnect: true
  });
  liveConnection = conn;

  conn.on(WebcastEvent.GIFT, (data) => {
    const user = cleanUser(data.user);
    const giftName = data.extendedGiftInfo?.name || data.giftDetails?.giftName || `מתנה ${data.giftId || ""}`;
    const count = Math.max(1, Number(data.repeatCount || 1));
    if (data.gift?.streakable && data.streaking) return;
    sendAll({ type:"gift", username:user.username, nickname:user.nickname, avatar:user.avatar, gift:giftName, count });
  });
  conn.on(WebcastEvent.MEMBER, (data) => {
    const user = cleanUser(data.user);
    sendAll({ type:"join", username:user.username, nickname:user.nickname, avatar:user.avatar });
  });
  conn.on(WebcastEvent.CHAT, (data) => {
    const user = cleanUser(data.user);
    sendAll({ type:"chat", username:user.username, nickname:user.nickname, comment:data.comment || "" });
  });
  conn.on(WebcastEvent.LIKE, (data) => {
    const user = cleanUser(data.user);
    sendAll({ type:"like", username:user.username, nickname:user.nickname, count:Number(data.count || 1) });
  });
  conn.on(WebcastEvent.FOLLOW, (data) => {
    const user = cleanUser(data.user);
    sendAll({ type:"follow", username:user.username, nickname:user.nickname });
  });
  conn.on("disconnected", () => sendAll({ type:"status", status:"disconnected", message:"החיבור לשידור נותק." }));
  conn.on("error", (err) => sendAll({ type:"status", status:"error", message:err?.message || "שגיאת חיבור" }));

  try {
    await conn.connect();
    sendAll({ type:"status", status:"connected", username, message:`מחובר ל־@${username}` });
  } catch (err) {
    await stopLive();
    throw new Error(err?.message || "לא הצלחנו להתחבר. ודא שהחשבון בשידור חי ונסה שוב.");
  }
}

wss.on("connection", (ws) => {
  clients.add(ws);
  ws.send(JSON.stringify({ type:"status", status: liveConnection?.isConnected ? "connected" : "idle",
    username:activeUsername, message:liveConnection?.isConnected ? `מחובר ל־@${activeUsername}` : "מוכן להתחברות" }));
  ws.on("message", async (raw) => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { return; }
    if (data.type === "connect") {
      try { await startLive(data.username); }
      catch (err) { ws.send(JSON.stringify({ type:"status", status:"error", message:err.message })); }
    } else if (data.type === "disconnect") {
      await stopLive();
      sendAll({ type:"status", status:"idle", message:"נותק מהשידור." });
    }
  });
  ws.on("close", () => clients.delete(ws));
});

const port = Number(process.env.PORT || 3000);
server.listen(port, "0.0.0.0", () => console.log(`LiveLoot running on ${port}`));
